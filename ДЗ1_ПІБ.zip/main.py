from pymongo import MongoClient
from pymongo.server_api import ServerApi

client = MongoClient(
    "mongodb+srv://dimon3dr:11051997Mongo!@cluster0.czleiqj.mongodb.net/myFirstDatabase?retryWrites=true&w=majority",
    server_api=ServerApi('1')
)

db = client.book

#Створення документа котика (Сreate)
result_one = db.cats.insert_one(
    {
        "name": "barsik",
        "age": 3,
        "features": ["ходить в капці", "дає себе гладити", "рудий"],
    }
)

print(result_one.inserted_id)

collection = db.cats

# Читання (Read)
def get_all_cats():
    cats = collection.find()
    for cat in cats:
        print(cat)

def get_cat_by_name(name):
    cat = collection.find_one({"name": name})
    if cat:
        print(cat)
    else:
        print("Кота з таким ім'ям не знайдено.")

# Оновлення (Update)
def update_cat_age(name, age):
    collection.update_one({"name": name}, {"$set": {"age": age}})
    print("Вік кота оновлено.")

def add_feature_to_cat(name, feature):
    collection.update_one({"name": name}, {"$push": {"features": feature}})
    print("Характеристику додано до кота.")

# Видалення (Delete)
def delete_cat_by_name(name):
    collection.delete_one({"name": name})
    print("Кота видалено.")

# Тестування функцій
if __name__ == "__main__":
    get_all_cats()
    get_cat_by_name("barsik")
    update_cat_age("barsik", 4)
    add_feature_to_cat("barsik", "любить спати на сонці")
    delete_cat_by_name("barsik")


